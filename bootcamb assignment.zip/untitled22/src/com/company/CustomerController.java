package com.company;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerController {
    //addCustomer
    public static int addCustomer(Customer cus) throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();

        String query = "INSERT INTO customers(customerId,customerName,eMail,address,contactNumber,dateOfBirth,gender) " +
                "VALUES('"+ cus.getCustomerId() +"','"+ cus.getCustomerName() +"','"+ cus.geteMail() +"','"+ cus.getAddress() +"','"+cus.getContactNo()+"','"+ cus.getDateOfBirth() +"','"+ cus.getGender() +"')";

        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //customerUpdate


    //customerDelete


    //get customer


    //get customers

}





