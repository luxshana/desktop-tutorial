package com.company;

import com.company.DataBaseConnection;
import com.company.Product;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductController {
    public static int addProduct(Product pro) throws ClassNotFoundException, SQLException {
        Connection con= DataBaseConnection.getConnection();

        Statement stmt = con.createStatement();
        String query = "INSERT INTO products(productId, productName, description, purchasePrice, sellingPrice, quantity) VALUES('"+ pro.getProductId() +"','"+ pro.getProductName() +"','"+ pro.getDescription() +"','"+ pro.getPurchasePrice() +"','"+ pro.getSellingPrice() +"','"+ pro.getQuantity() +"')";

        return stmt.executeUpdate(query);//executeUpdate will return integer value
    }

    //Get all products from database
    public static ArrayList getProducts() throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();
        ArrayList productArray = new ArrayList();

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM products";
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String productId = rs.getString("productId");
            String productName = rs.getString("productName");
            String desc = rs.getString("description");
            double purchacePrice = Double.parseDouble(rs.getString("purchasePrice"));
            double sellingPrice = Double.parseDouble(rs.getString("sellingPrice"));
            int quantity = Integer.parseInt(rs.getString("quantity"));

            Product pro = new Product(productId,productName,desc,purchacePrice,sellingPrice,quantity);
            productArray.add(pro);
        }
        return productArray;
    }

    //Get single product from database
    public static Product getProduct(String pID) throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();

        Product pro = null;

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM products WHERE productId="+pID;
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String productId = rs.getString("productId");
            String productName = rs.getString("productName");
            String desc = rs.getString("description");
            double purchacePrice = Double.parseDouble(rs.getString("purchasePrice"));
            double sellingPrice = Double.parseDouble(rs.getString("sellingPrice"));
            int quantity = Integer.parseInt(rs.getString("quantity"));

            pro = new Product(productId,productName,desc,purchacePrice,sellingPrice,quantity);
        }
        return pro;
    }

    //Delete product from database
    public static int deleteProduct(String pID) throws SQLException, ClassNotFoundException{
        Connection con = DataBaseConnection.getConnection();

        String query = "DELETE FROM products WHERE productId="+pID;
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //Update product in database
    public static int updateProduct(String pID, Product pro) throws ClassNotFoundException, SQLException{
        Connection con = DataBaseConnection.getConnection();

        String query = "UPDATE products SET( productName='"+ pro.getProductName() +"', description='"+ pro.getDescription() +"', purchasePrice='"+ pro.getPurchasePrice() +"', sellingPrice='"+ pro.getSellingPrice() +"', quantity='"+ pro.getQuantity() +"')  WHERE productId='"+ pID +"'";
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }
}
