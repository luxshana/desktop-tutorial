package Customer;

public class Customer {
    private String customerId;
    private String customerName;
    private  String eMail;
    private String address;
    private String contactNo;
    private String gender;
    private String dateOfBirth;

    public Customer(String customerId, String customerName, String eMail, String address, String contactNo, String gender, String dateOfBirth) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.eMail = eMail;
        this.address = address;
        this.contactNo = contactNo;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
    }

    public Customer() {

    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}

